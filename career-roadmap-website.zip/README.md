# PathFinder - Hyper-Specific Career Roadmap

An interactive web application to map, track, and reverse-engineer career roadmaps for hyper-specific dream tech roles (AI Engineer, ML Engineer, Quant Engineer, Professor, Teacher, Trainer, and more).

## Key Features
- **Interactive Live Skill Gap & Readiness Index**: Dynamic recalculation of Goal Preparedness %, possessed skills, gaps to bridge, and remaining study hours without page reload.
- **Dream Job Role Search**: Real-time search across job titles, tech domains, and core competencies.
- **Month-Wise Timeline Roadmap**: Sequential curriculum with learning resource checkboxes and progress bars.
- **Competency Node Graph**: Visual prerequisite and dependency graph.
- **Reverse-Engineered Skill Matrix**: Verification levels and live possession toggling.
- **Certificate Vault**: Upload and verify certifications with credential tracking.
- **Google Authentication & Firebase Persistence**: Cloud sync for custom roadmaps.

## Getting Started

### Prerequisites
- Node.js 18+ or 20+
- npm (or yarn / pnpm / bun)

### 1. Install dependencies
```bash
npm install
```

### 2. Run Development Server
```bash
npm run dev
```
The application will launch on `http://localhost:3000`.

### 3. Build for Production
```bash
npm run build
```

### 4. Preview Production Build
```bash
npm run preview
```
